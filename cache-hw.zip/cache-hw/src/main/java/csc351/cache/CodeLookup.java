package csc351.cache;

import java.util.Optional;

public interface CodeLookup {
    Integer find(String item);
}
